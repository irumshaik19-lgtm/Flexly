
import { GoogleGenAI } from "@google/genai";

// Initialize GoogleGenAI using process.env.API_KEY directly
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getGymSummary = async (gymName: string, amenities: string[], location: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Write a catchy, highly engaging 2-sentence marketing summary for a gym called "${gymName}" located in ${location}. Highlights: ${amenities.join(', ')}. Format: Professional and energetic.`,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return `Experience premium fitness at ${gymName} in ${location}.`;
  }
};

export const getAIFitnessTip = async (goal: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Give one short, expert fitness tip for someone looking to ${goal}. Keep it under 15 words and very punchy.`,
    });
    return response.text;
  } catch (error) {
    return "Stay hydrated and keep pushing your limits!";
  }
};
