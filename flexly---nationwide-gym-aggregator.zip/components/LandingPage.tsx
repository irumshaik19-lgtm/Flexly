
import React, { useState, useEffect, useRef } from 'react';
import { UserRole } from '../types';
import { FEATURES, APP_NAME, MOCK_GYMS, TOP_CITIES } from '../constants';
import { ArrowRight, Play, CheckCircle2, MapPin, Star, Zap, Shield, Globe, ChevronLeft, ChevronRight, Users } from 'lucide-react';

interface Props {
  onLogin: (role: UserRole) => void;
}

const LandingPage: React.FC<Props> = ({ onLogin }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const { scrollLeft, clientWidth } = scrollRef.current;
      const scrollTo = direction === 'left' ? scrollLeft - clientWidth : scrollLeft + clientWidth;
      scrollRef.current.scrollTo({ left: scrollTo, behavior: 'smooth' });
    }
  };

  return (
    <div className="relative bg-slate-950 text-white overflow-x-hidden">
      {/* Navigation Overlay */}
      <header className="fixed top-0 left-0 right-0 z-50 glass-morphism border-b border-white/5">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-500 rounded-xl flex items-center justify-center text-slate-950 font-black text-xl shadow-lg shadow-emerald-500/30">F</div>
            <span className="text-2xl font-black tracking-tighter text-white">{APP_NAME}</span>
          </div>
          <nav className="hidden lg:flex items-center gap-8 text-xs font-black uppercase tracking-widest text-slate-400">
            <a href="#benefits" className="hover:text-emerald-400 transition-colors">Benefits</a>
            <a href="#network" className="hover:text-emerald-400 transition-colors">The Network</a>
            <a href="#partner" className="hover:text-emerald-400 transition-colors">For Gyms</a>
          </nav>
          <div className="flex items-center gap-6">
            <button onClick={() => onLogin(UserRole.OWNER)} className="hidden sm:block text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-white transition-colors">Partner Login</button>
            <button onClick={() => onLogin(UserRole.USER)} className="px-8 py-3 bg-emerald-500 text-slate-950 text-[10px] font-black rounded-full uppercase tracking-widest hover:bg-emerald-400 transition-all shadow-lg shadow-emerald-500/20">Join Now</button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative min-h-screen flex flex-col items-center justify-center pt-20 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1920&q=80')] bg-cover bg-center opacity-30 scale-105"></div>
          <div className="absolute inset-0 bg-gradient-to-b from-slate-950 via-slate-950/60 to-slate-950"></div>
          {/* Animated Background Orbs */}
          <div className="absolute top-1/4 -left-20 w-96 h-96 bg-emerald-500/10 rounded-full blur-[120px] animate-pulse"></div>
          <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-blue-500/10 rounded-full blur-[120px] animate-pulse delay-1000"></div>
        </div>

        <div className="relative z-10 max-w-5xl mx-auto px-6 text-center space-y-8">
          <div className="inline-flex items-center gap-3 px-6 py-2 bg-emerald-500/10 border border-emerald-500/20 rounded-full text-emerald-400 text-[10px] font-black uppercase tracking-[0.3em] mb-4">
            <Globe className="w-3 h-3" /> Fitness Freedom Across India
          </div>
          <h1 className="text-6xl md:text-9xl font-black leading-[0.85] tracking-tighter">
            WORKOUT <br />
            <span className="bg-gradient-to-r from-emerald-400 via-emerald-300 to-cyan-400 bg-clip-text text-transparent">ANYWHERE.</span>
          </h1>
          <p className="text-lg md:text-2xl text-slate-400 max-w-3xl mx-auto font-medium leading-relaxed">
            One digital pass, 2,500+ premium gyms. No registration fees, no monthly lock-ins. Pay only for the days you train.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center pt-6">
            <button 
              onClick={() => onLogin(UserRole.USER)}
              className="group px-12 py-6 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-2xl flex items-center justify-center gap-4 transition-all transform hover:scale-105 shadow-2xl shadow-emerald-500/30 text-lg uppercase tracking-widest"
            >
              Get Your Pass <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
            </button>
            <button className="flex items-center gap-4 px-8 py-6 bg-white/5 border border-white/10 rounded-2xl text-white font-black uppercase tracking-widest text-sm hover:bg-white/10 transition-all">
              <Play className="w-5 h-5 fill-current" />
              Watch Video
            </button>
          </div>
          
          <div className="pt-12 flex flex-wrap justify-center items-center gap-x-12 gap-y-6 opacity-40">
             {TOP_CITIES.map(city => (
               <span key={city} className="text-xs font-black uppercase tracking-[0.2em]">{city}</span>
             ))}
          </div>
        </div>
      </section>

      {/* Featured Network Slider */}
      <section id="network" className="py-32 bg-slate-900/30">
        <div className="max-w-7xl mx-auto px-6 mb-16 flex flex-col md:flex-row justify-between items-end gap-6">
          <div className="space-y-4">
            <h2 className="text-xs font-black text-emerald-400 uppercase tracking-[0.4em]">The Network</h2>
            <h3 className="text-5xl font-black tracking-tight">Access Elite Studios</h3>
            <p className="text-slate-500 font-medium max-w-md">From crossfit boxes to premium bodybuilding temples, discover the best fitness infrastructure near you.</p>
          </div>
          <div className="flex gap-4">
            <button onClick={() => scroll('left')} className="p-4 bg-slate-800 rounded-2xl hover:bg-emerald-500 hover:text-slate-950 transition-all shadow-xl"><ChevronLeft className="w-6 h-6" /></button>
            <button onClick={() => scroll('right')} className="p-4 bg-slate-800 rounded-2xl hover:bg-emerald-400 hover:text-slate-950 transition-all shadow-xl"><ChevronRight className="w-6 h-6" /></button>
          </div>
        </div>
        
        <div 
          ref={scrollRef}
          className="flex gap-8 overflow-x-auto pb-12 px-6 no-scrollbar snap-x scroll-smooth"
        >
          {MOCK_GYMS.map((gym) => (
            <div 
              key={gym.id} 
              className="min-w-[340px] md:min-w-[450px] snap-center group cursor-pointer"
              onClick={() => onLogin(UserRole.USER)}
            >
              <div className="relative h-[500px] rounded-[3rem] overflow-hidden border border-white/5 shadow-2xl">
                <img src={gym.photos[0]} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" alt={gym.name} />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent"></div>
                
                <div className="absolute top-8 left-8 flex gap-2">
                   <span className="px-4 py-1.5 bg-black/50 backdrop-blur-md rounded-full text-[10px] font-black text-white uppercase border border-white/10 tracking-widest">{gym.tags[0]}</span>
                </div>

                <div className="absolute bottom-10 left-10 right-10 space-y-4">
                  <div className="flex justify-between items-end">
                    <div className="space-y-1">
                       <h4 className="text-3xl font-black text-white leading-tight">{gym.name}</h4>
                       <p className="text-slate-400 text-sm flex items-center gap-2 font-bold"><MapPin className="w-4 h-4 text-emerald-500" /> {gym.location}</p>
                    </div>
                    <div className="text-right">
                       <p className="text-2xl font-black text-emerald-400">₹{gym.pricing.daily}</p>
                       <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Daily Pass</p>
                    </div>
                  </div>
                  <div className="pt-4 flex items-center gap-6 border-t border-white/10">
                    <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
                      <Star className="w-4 h-4 text-yellow-400 fill-current" /> {gym.rating}
                    </div>
                    <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
                      <Users className="w-4 h-4 text-emerald-500" /> {gym.reviewsCount} Active Members
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Benefits / Features Section */}
      <section id="benefits" className="py-40 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
            <div className="space-y-12">
              <div className="space-y-6">
                <h2 className="text-xs font-black text-emerald-400 uppercase tracking-[0.5em]">The Flexly Benefit</h2>
                <h3 className="text-6xl md:text-7xl font-black leading-[0.9] tracking-tighter">Your Fitness. <br />Decentralized.</h3>
                <p className="text-xl text-slate-400 font-medium leading-relaxed">We are dismantling the old, restrictive gym membership model. Flexly gives you the power to choose where you train today, tomorrow, and forever.</p>
              </div>
              
              <div className="grid grid-cols-1 gap-10">
                {FEATURES.map((f, i) => (
                  <div key={i} className="flex gap-8 group">
                    <div className="w-20 h-20 bg-slate-900 border border-white/10 rounded-3xl flex items-center justify-center text-emerald-400 shrink-0 shadow-2xl transition-all group-hover:bg-emerald-500 group-hover:text-slate-950 group-hover:rotate-6">
                      {f.icon}
                    </div>
                    <div className="space-y-2">
                      <h4 className="text-2xl font-black tracking-tight">{f.title}</h4>
                      <p className="text-slate-500 leading-relaxed font-medium">{f.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative">
              <div className="absolute -inset-10 bg-emerald-500/20 rounded-full blur-[100px] animate-pulse"></div>
              <div className="relative bg-slate-900 border border-white/10 rounded-[4rem] p-6 shadow-2xl">
                <img 
                  src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&w=1000&q=80" 
                  className="rounded-[3.5rem] grayscale hover:grayscale-0 transition-all duration-1000 object-cover aspect-square"
                  alt="Flexly Lifestyle"
                />
                <div className="absolute -bottom-10 -right-10 bg-white p-10 rounded-[3rem] shadow-2xl rotate-6 hidden md:block">
                  <div className="flex items-center gap-6">
                    <div className="w-16 h-16 bg-emerald-500 rounded-2xl flex items-center justify-center text-slate-950">
                       <Shield className="w-8 h-8" />
                    </div>
                    <div>
                       <p className="text-slate-900 text-3xl font-black tracking-tighter">ISO 9001</p>
                       <p className="text-slate-400 text-xs font-bold uppercase tracking-widest">Safety Certified</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* For Gym Partners Section */}
      <section id="partner" className="py-32 bg-emerald-500 text-slate-950">
        <div className="max-w-7xl mx-auto px-6">
           <div className="flex flex-col lg:flex-row items-center justify-between gap-16">
              <div className="max-w-2xl space-y-8">
                <h3 className="text-6xl font-black tracking-tighter leading-none">Own a Gym? <br />Fill Every Slot.</h3>
                <p className="text-xl font-bold opacity-70 leading-relaxed">Monetize your off-peak hours and reach thousands of new fitness enthusiasts. We handle payments, verification, and marketing while you focus on training.</p>
                <div className="flex flex-wrap gap-4">
                   <div className="px-6 py-3 bg-slate-950/10 border border-slate-950/10 rounded-full flex items-center gap-3 font-black text-sm">
                      <CheckCircle2 className="w-5 h-5" /> Instant Payouts
                   </div>
                   <div className="px-6 py-3 bg-slate-950/10 border border-slate-950/10 rounded-full flex items-center gap-3 font-black text-sm">
                      <CheckCircle2 className="w-5 h-5" /> Zero Setup Cost
                   </div>
                </div>
              </div>
              <button 
                onClick={() => onLogin(UserRole.OWNER)}
                className="px-16 py-8 bg-slate-950 text-white font-black text-xl rounded-[2.5rem] hover:bg-slate-900 transition-all shadow-2xl transform hover:-translate-y-2 uppercase tracking-[0.2em]"
              >
                Become a Partner
              </button>
           </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-20 border-t border-white/5 bg-slate-950">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="md:col-span-2 space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-emerald-500 rounded-xl flex items-center justify-center text-slate-950 font-black text-xl">F</div>
              <span className="text-3xl font-black tracking-tighter text-white">{APP_NAME}</span>
            </div>
            <p className="text-slate-500 font-medium max-w-sm">Reimagining fitness access for the modern world. One pass, endless possibilities across the nation.</p>
          </div>
          <div className="space-y-6">
            <h4 className="text-xs font-black uppercase tracking-widest text-white">Platform</h4>
            <ul className="space-y-4 text-slate-500 text-sm font-bold uppercase tracking-widest">
              <li><a href="#" className="hover:text-emerald-400 transition-colors">How it works</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">For Gym Owners</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Safety Protocols</a></li>
              <li><button onClick={() => onLogin(UserRole.ADMIN)} className="hover:text-rose-400 transition-colors">Admin Governance</button></li>
            </ul>
          </div>
          <div className="space-y-6">
            <h4 className="text-xs font-black uppercase tracking-widest text-white">Legal</h4>
            <ul className="space-y-4 text-slate-500 text-sm font-bold uppercase tracking-widest">
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Terms of Service</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Cookie Policy</a></li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-6 mt-20 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6 text-[10px] font-black uppercase tracking-widest text-slate-600">
           <span>© 2024 Flexly Technologies Pvt. Ltd.</span>
           <div className="flex gap-8">
              <a href="#" className="hover:text-white">Twitter</a>
              <a href="#" className="hover:text-white">Instagram</a>
              <a href="#" className="hover:text-white">LinkedIn</a>
           </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
