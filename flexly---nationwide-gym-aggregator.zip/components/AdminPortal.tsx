
import React, { useState, useMemo } from 'react';
import { useLocation } from 'react-router-dom';
import { User, Gym, Booking, UserRole } from '../types';
import { MOCK_GYMS, PLATFORM_CONFIG, MOCK_USERS, MOCK_PAYMENTS } from '../constants';
import { 
  ShieldCheck, Users, Dumbbell, Receipt, Check, X, Eye, MapPin, 
  ArrowUpRight, Search, Filter, CreditCard, User as UserIcon, 
  Mail, MoreHorizontal, Settings, Percent, Wallet, Download, 
  Database, FileSpreadsheet, PieChart, TrendingUp, AlertCircle,
  Building, CheckCircle2, Landmark
} from 'lucide-react';
import { BarChart, Bar, ResponsiveContainer, XAxis, YAxis, Tooltip, Cell, LineChart, Line, AreaChart, Area } from 'recharts';

const AdminPortal: React.FC<{ user: User }> = ({ user }) => {
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'ACCOUNTING' | 'USERS' | 'GYMS' | 'APPROVALS' | 'CONFIG' | 'DATABASE'>('OVERVIEW');
  const [config, setConfig] = useState(PLATFORM_CONFIG);
  const [searchTerm, setSearchTerm] = useState('');
  const [cityFilter, setCityFilter] = useState('All');

  // Logic: Filters & Aggregations
  const totalGTV = MOCK_PAYMENTS.reduce((sum, p) => sum + p.grossAmount, 0);
  const totalCommission = MOCK_PAYMENTS.reduce((sum, p) => sum + p.commissionAmount, 0);
  const totalGST = MOCK_PAYMENTS.reduce((sum, p) => sum + p.gstAmount, 0);

  const filteredUsers = useMemo(() => {
    return MOCK_USERS.filter(u => 
      (u.name.toLowerCase().includes(searchTerm.toLowerCase()) || u.email.toLowerCase().includes(searchTerm.toLowerCase())) &&
      (cityFilter === 'All' || u.city === cityFilter)
    );
  }, [searchTerm, cityFilter]);

  const filteredGyms = useMemo(() => {
    return MOCK_GYMS.filter(g => 
      (g.name.toLowerCase().includes(searchTerm.toLowerCase()) || g.ownerName?.toLowerCase().includes(searchTerm.toLowerCase())) &&
      (cityFilter === 'All' || g.city === cityFilter)
    );
  }, [searchTerm, cityFilter]);

  const exportToExcel = (type: string) => {
    alert(`Extracting Master ${type} Data for Excel...\nFile generated: flexly_${type.toLowerCase()}_master_report.xlsx`);
  };

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-8 pb-24 text-slate-100">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h1 className="text-4xl font-black tracking-tighter uppercase flex items-center gap-4">
             Admin Command Center
             <span className="px-3 py-1 bg-emerald-500 text-slate-950 text-[9px] font-black rounded-lg uppercase tracking-widest animate-pulse">Live Backend</span>
          </h1>
          <p className="text-slate-500 font-bold mt-1 uppercase text-[10px] tracking-widest">Master Control & Financial Orchestration</p>
        </div>
        <div className="flex flex-wrap gap-3">
          <TabButton active={activeTab === 'OVERVIEW'} onClick={() => setActiveTab('OVERVIEW')} icon={<TrendingUp className="w-4 h-4" />} label="Trends" />
          <TabButton active={activeTab === 'ACCOUNTING'} onClick={() => setActiveTab('ACCOUNTING')} icon={<Receipt className="w-4 h-4" />} label="Accounting" />
          <TabButton active={activeTab === 'APPROVALS'} onClick={() => setActiveTab('APPROVALS')} icon={<ShieldCheck className="w-4 h-4" />} label="Approvals" />
          <TabButton active={activeTab === 'DATABASE'} onClick={() => setActiveTab('DATABASE')} icon={<Database className="w-4 h-4" />} label="Data Master" />
          <TabButton active={activeTab === 'CONFIG'} onClick={() => setActiveTab('CONFIG')} icon={<Settings className="w-4 h-4" />} label="Policies" />
        </div>
      </div>

      {activeTab === 'OVERVIEW' && (
        <div className="space-y-8 animate-in fade-in duration-500">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <StatCard title="Global GTV" value={`₹${totalGTV.toLocaleString()}`} icon={<Wallet className="w-6 h-6 text-emerald-400" />} change="+18%" />
            <StatCard title="Plat. Commission" value={`₹${totalCommission.toLocaleString()}`} icon={<Percent className="w-6 h-6 text-blue-400" />} />
            <StatCard title="Active Members" value={MOCK_USERS.filter(u => u.subscriptionStatus === 'SUBSCRIBED').length.toString()} icon={<Users className="w-6 h-6 text-purple-400" />} />
            <StatCard title="Partner Studios" value={MOCK_GYMS.length.toString()} icon={<Building className="w-6 h-6 text-amber-400" />} />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 bg-slate-900 border border-slate-800 p-8 rounded-[2.5rem] shadow-2xl">
               <h3 className="text-xl font-black uppercase tracking-tight mb-8">Platform Growth Curve</h3>
               <div className="h-[350px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={[
                      { name: 'Jan', val: 4000 }, { name: 'Feb', val: 3000 }, { name: 'Mar', val: 5000 }, { name: 'Apr', val: 8000 }, { name: 'May', val: 12000 }
                    ]}>
                      <XAxis dataKey="name" hide />
                      <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b' }} />
                      <Area type="monotone" dataKey="val" stroke="#10b981" fill="rgba(16, 185, 129, 0.1)" strokeWidth={4} />
                    </AreaChart>
                  </ResponsiveContainer>
               </div>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-8 rounded-[2.5rem] shadow-2xl">
               <h3 className="text-xl font-black uppercase tracking-tight mb-8">Pending Items</h3>
               <div className="space-y-4">
                  <PendingItem type="GYM" label="Iron Palace - KYC" time="2h ago" />
                  <PendingItem type="LISTING" label="Yoga Studio #2" time="4h ago" />
                  <PendingItem type="PAYOUT" label="Request: WRD-991" time="1d ago" />
               </div>
               <button onClick={() => setActiveTab('APPROVALS')} className="w-full mt-10 py-4 bg-slate-800 text-xs font-black uppercase tracking-widest rounded-xl hover:bg-slate-700 transition-all">Clear All Backlog</button>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'ACCOUNTING' && (
        <div className="space-y-8 animate-in slide-in-from-bottom-4">
           <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-slate-900 border border-slate-800 p-8 rounded-[2rem]">
                 <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Total GST Collected (18%)</p>
                 <h4 className="text-4xl font-black text-blue-400">₹{totalGST.toLocaleString()}</h4>
              </div>
              <div className="bg-slate-900 border border-slate-800 p-8 rounded-[2rem]">
                 <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Platform Net Earnings</p>
                 <h4 className="text-4xl font-black text-emerald-400">₹{totalCommission.toLocaleString()}</h4>
              </div>
              <div className="bg-slate-900 border border-slate-800 p-8 rounded-[2rem]">
                 <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Liability to Partners</p>
                 <h4 className="text-4xl font-black text-amber-400">₹{MOCK_PAYMENTS.reduce((s,p) => s+p.netPayoutToOwner, 0).toLocaleString()}</h4>
              </div>
           </div>

           <div className="bg-slate-900 border border-slate-800 rounded-[2.5rem] overflow-hidden shadow-2xl">
              <div className="p-8 border-b border-slate-800 flex justify-between items-center">
                 <h3 className="text-2xl font-black uppercase tracking-tighter">Global Ledger</h3>
                 <button onClick={() => exportToExcel('Accounting')} className="flex items-center gap-2 px-6 py-3 bg-white text-slate-950 rounded-xl text-[10px] font-black uppercase tracking-widest"><FileSpreadsheet className="w-4 h-4" /> Export Report</button>
              </div>
              <div className="overflow-x-auto">
                 <table className="w-full text-left">
                    <thead className="bg-slate-800/50 text-slate-500 text-[9px] font-black uppercase tracking-[0.2em]">
                       <tr>
                          <th className="px-8 py-5">TXN Date</th>
                          <th className="px-8 py-5">Invoice / Member</th>
                          <th className="px-8 py-5">Gross Amount</th>
                          <th className="px-8 py-5">GST (18%)</th>
                          <th className="px-8 py-5">Flexly Fee ({(config.commissionRate * 100).toFixed(0)}%)</th>
                          <th className="px-8 py-5">Partner Net</th>
                          <th className="px-8 py-5">Mode</th>
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                       {MOCK_PAYMENTS.map(p => (
                          <tr key={p.id} className="hover:bg-slate-800/30 transition-all text-xs">
                             <td className="px-8 py-6 font-bold text-slate-500 uppercase">{p.date}</td>
                             <td className="px-8 py-6">
                                <p className="font-black uppercase tracking-tight">{p.userName}</p>
                                <p className="text-[10px] font-mono text-slate-600">{p.id}</p>
                             </td>
                             <td className="px-8 py-6 font-bold">₹{p.grossAmount}</td>
                             <td className="px-8 py-6 text-blue-400">₹{p.gstAmount}</td>
                             <td className="px-8 py-6 text-rose-400">₹{p.commissionAmount}</td>
                             <td className="px-8 py-6 font-black text-emerald-400">₹{p.netPayoutToOwner}</td>
                             <td className="px-8 py-6 font-black text-[10px] uppercase">{p.paymentMethod}</td>
                          </tr>
                       ))}
                    </tbody>
                 </table>
              </div>
           </div>
        </div>
      )}

      {activeTab === 'APPROVALS' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-in zoom-in-95">
           <div className="bg-slate-900 border border-slate-800 p-8 rounded-[2.5rem] shadow-2xl space-y-8">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-black uppercase tracking-tight flex items-center gap-3"><Landmark className="w-5 h-5 text-emerald-400" /> Partner KYC Audit</h3>
                <span className="bg-amber-500/10 text-amber-500 text-[10px] font-black px-3 py-1 rounded-full border border-amber-500/20">3 Pending</span>
              </div>
              <div className="space-y-4">
                 <AuditCard name="Amit Sharma" type="Sole Proprietor" id="GST-99212" />
                 <AuditCard name="Sunil Shetty" type="Private Limited" id="GST-11028" />
              </div>
           </div>
           <div className="bg-slate-900 border border-slate-800 p-8 rounded-[2.5rem] shadow-2xl space-y-8">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-black uppercase tracking-tight flex items-center gap-3"><Dumbbell className="w-5 h-5 text-blue-400" /> Listing Verification</h3>
                <span className="bg-amber-500/10 text-amber-500 text-[10px] font-black px-3 py-1 rounded-full border border-amber-500/20">1 Pending</span>
              </div>
              <div className="space-y-4">
                 {MOCK_GYMS.filter(g => g.status === 'PENDING').map(g => (
                    <div key={g.id} className="p-6 bg-slate-800/40 rounded-3xl border border-slate-700/50 flex justify-between items-center group">
                       <div className="flex gap-4 items-center">
                          <img src={g.photos[0]} className="w-16 h-16 rounded-2xl object-cover" />
                          <div>
                             <p className="font-black uppercase tracking-tight">{g.name}</p>
                             <p className="text-[10px] text-slate-500 font-bold">{g.location}</p>
                          </div>
                       </div>
                       <div className="flex gap-2">
                          <button className="p-3 bg-emerald-500 text-slate-950 rounded-xl hover:scale-110 transition-transform"><Check className="w-4 h-4" /></button>
                          <button className="p-3 bg-rose-500 text-white rounded-xl hover:scale-110 transition-transform"><X className="w-4 h-4" /></button>
                       </div>
                    </div>
                 ))}
              </div>
           </div>
        </div>
      )}

      {activeTab === 'DATABASE' && (
        <div className="max-w-4xl mx-auto space-y-12 py-12 text-center animate-in zoom-in-95">
           <div className="space-y-4">
              <div className="w-24 h-24 bg-emerald-500/10 rounded-[2rem] flex items-center justify-center text-emerald-400 mx-auto border border-emerald-500/20">
                 <Database className="w-12 h-12" />
              </div>
              <h2 className="text-4xl font-black tracking-tight uppercase">Master Data Extraction</h2>
              <p className="text-slate-500 font-medium max-w-md mx-auto">Export lifetime system snapshots for financial audits and marketing analytics.</p>
           </div>
           
           <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <ExportCard icon={<Users className="w-6 h-6" />} label="Member Master" sub="All Users & Leads" onClick={() => exportToExcel('Users')} />
              <ExportCard icon={<Landmark className="w-6 h-6" />} label="Partner Master" sub="Owners & Facilities" onClick={() => exportToExcel('Gyms')} />
              <ExportCard icon={<CreditCard className="w-6 h-6" />} label="Financial Master" sub="All Transactions" onClick={() => exportToExcel('Transactions')} />
           </div>
        </div>
      )}

      {activeTab === 'CONFIG' && (
        <div className="max-w-4xl bg-slate-900 border border-slate-800 p-12 rounded-[3rem] shadow-2xl animate-in zoom-in-95">
           <h3 className="text-2xl font-black mb-10 uppercase tracking-tight">Platform Global Settings</h3>
           <div className="space-y-10">
              <div className="grid grid-cols-2 gap-10">
                 <div className="space-y-4">
                    <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Default Commission (%)</label>
                    <div className="flex items-center gap-6">
                       <input 
                        type="range" min="5" max="30" value={config.commissionRate * 100}
                        onChange={(e) => setConfig({...config, commissionRate: parseInt(e.target.value)/100})}
                        className="flex-grow accent-emerald-500"
                       />
                       <span className="w-16 text-center font-black text-emerald-400">{(config.commissionRate * 100).toFixed(0)}%</span>
                    </div>
                 </div>
                 <div className="space-y-4">
                    <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">GST Surcharge (%)</label>
                    <div className="flex items-center gap-6">
                       <input 
                        type="range" min="0" max="28" value={config.gstRate * 100}
                        onChange={(e) => setConfig({...config, gstRate: parseInt(e.target.value)/100})}
                        className="flex-grow accent-blue-500"
                       />
                       <span className="w-16 text-center font-black text-blue-400">{(config.gstRate * 100).toFixed(0)}%</span>
                    </div>
                 </div>
              </div>
              <div className="p-8 bg-emerald-500/5 border border-emerald-500/10 rounded-3xl flex items-center gap-6">
                 <AlertCircle className="w-8 h-8 text-emerald-400 shrink-0" />
                 <p className="text-xs text-slate-400 font-medium leading-relaxed italic">Changes to commission policies are applied globally to all new transactions immediately. Payout settlements for existing pending transactions will follow the policy active at the time of booking.</p>
              </div>
              <button className="w-full py-5 bg-emerald-500 text-slate-950 font-black rounded-2xl uppercase tracking-widest text-sm hover:bg-emerald-400 shadow-xl shadow-emerald-500/20">Deploy Policy Updates</button>
           </div>
        </div>
      )}
    </div>
  );
};

// Sub-components
const TabButton: React.FC<{ active: boolean; onClick: () => void; icon: React.ReactNode; label: string }> = ({ active, onClick, icon, label }) => (
  <button 
    onClick={onClick}
    className={`flex items-center gap-3 px-6 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${active ? 'bg-emerald-500 text-slate-950 shadow-xl shadow-emerald-500/20' : 'bg-slate-900 border border-slate-800 text-slate-500 hover:text-white'}`}
  >
    {icon} {label}
  </button>
);

const StatCard: React.FC<{ title: string; value: string; icon: React.ReactNode; change?: string }> = ({ title, value, icon, change }) => (
  <div className="bg-slate-900 border border-slate-800 p-8 rounded-[2rem] hover:border-emerald-500/30 transition-all group shadow-xl">
    <div className="p-4 bg-slate-800 rounded-2xl w-fit mb-6 group-hover:scale-110 transition-transform duration-500">{icon}</div>
    <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.2em]">{title}</p>
    <h3 className="text-3xl font-black mt-2 tracking-tighter">{value}</h3>
    {change && <p className="text-[10px] font-black text-emerald-400 uppercase mt-2">{change}</p>}
  </div>
);

const PendingItem: React.FC<{ type: string; label: string; time: string }> = ({ type, label, time }) => (
  <div className="flex items-center justify-between p-4 bg-slate-800/40 border border-slate-800 rounded-2xl">
     <div className="flex items-center gap-3">
        <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-[10px] font-black ${type === 'GYM' ? 'bg-blue-500/10 text-blue-400' : 'bg-amber-500/10 text-amber-400'}`}>{type[0]}</div>
        <div>
           <p className="text-xs font-black uppercase tracking-tight">{label}</p>
           <p className="text-[10px] text-slate-600 font-bold">{time}</p>
        </div>
     </div>
     <ChevronRightIcon className="w-4 h-4 text-slate-700" />
  </div>
);

const AuditCard: React.FC<{ name: string; type: string; id: string }> = ({ name, type, id }) => (
  <div className="p-6 bg-slate-800/40 rounded-3xl border border-slate-700/50 flex justify-between items-center group">
     <div className="flex gap-4 items-center">
        <div className="w-14 h-14 bg-slate-900 rounded-2xl flex items-center justify-center text-slate-500 font-black">{name[0]}</div>
        <div>
           <p className="font-black uppercase tracking-tight">{name}</p>
           <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">{type} • {id}</p>
        </div>
     </div>
     <div className="flex gap-2">
        <button className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl hover:bg-emerald-500 hover:text-slate-950 transition-all"><CheckCircle2 className="w-4 h-4" /></button>
        <button className="p-3 bg-rose-500/10 text-rose-500 rounded-xl hover:bg-rose-500 hover:text-white transition-all"><X className="w-4 h-4" /></button>
     </div>
  </div>
);

const ExportCard: React.FC<{ icon: React.ReactNode; label: string; sub: string; onClick: () => void }> = ({ icon, label, sub, onClick }) => (
  <button 
    onClick={onClick}
    className="p-8 bg-slate-900 border border-slate-800 rounded-[2.5rem] hover:border-emerald-500/30 transition-all group flex flex-col items-center gap-4 shadow-xl"
  >
    <div className="p-5 bg-slate-800 rounded-2xl group-hover:bg-emerald-500 group-hover:text-slate-950 transition-all">{icon}</div>
    <div>
       <p className="font-black text-white uppercase text-xs tracking-[0.2em]">{label}</p>
       <p className="text-[10px] text-slate-600 font-bold uppercase mt-1 tracking-widest">{sub}</p>
    </div>
  </button>
);

const ChevronRightIcon = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9 5l7 7-7 7" /></svg>
);

export default AdminPortal;
