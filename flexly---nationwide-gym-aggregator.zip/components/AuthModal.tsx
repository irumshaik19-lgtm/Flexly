
import React, { useState } from 'react';
import { UserRole } from '../types';
import { X, Mail, Phone, Chrome, ArrowRight, Github, Twitter } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onAuth: (role: UserRole) => void;
}

const AuthModal: React.FC<Props> = ({ isOpen, onClose, onAuth }) => {
  const [method, setMethod] = useState<'EMAIL' | 'PHONE'>('EMAIL');
  const [isLogin, setIsLogin] = useState(true);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md" onClick={onClose}></div>
      <div className="bg-slate-900 border border-slate-800 w-full max-w-md rounded-[2.5rem] overflow-hidden relative z-10 shadow-2xl animate-in zoom-in-95 duration-300">
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 p-2 bg-slate-800 rounded-full text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-8 md:p-10">
          <div className="text-center mb-10">
            <div className="w-16 h-16 bg-emerald-500 rounded-2xl flex items-center justify-center text-slate-950 font-black text-3xl mx-auto mb-6 shadow-xl shadow-emerald-500/20">F</div>
            <h2 className="text-3xl font-black tracking-tight">{isLogin ? 'Welcome Back' : 'Join Flexly'}</h2>
            <p className="text-slate-400 mt-2">{isLogin ? 'Unlock your fitness freedom today' : 'Start your journey with a single pass'}</p>
          </div>

          <div className="space-y-4">
            {/* Social Logins */}
            <button 
              onClick={() => onAuth(UserRole.USER)}
              className="w-full flex items-center justify-center gap-3 px-6 py-4 bg-white text-slate-950 font-bold rounded-2xl hover:bg-slate-100 transition-all group"
            >
              <Chrome className="w-5 h-5" /> Continue with Google
            </button>
            
            <div className="flex items-center gap-4 my-8">
              <div className="flex-1 h-px bg-slate-800"></div>
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Or use your credentials</span>
              <div className="flex-1 h-px bg-slate-800"></div>
            </div>

            {/* Tabs */}
            <div className="flex bg-slate-800 p-1 rounded-xl mb-6">
              <button 
                onClick={() => setMethod('EMAIL')}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-xs font-black transition-all ${method === 'EMAIL' ? 'bg-slate-700 text-white shadow-lg' : 'text-slate-500'}`}
              >
                <Mail className="w-4 h-4" /> Email
              </button>
              <button 
                onClick={() => setMethod('PHONE')}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-xs font-black transition-all ${method === 'PHONE' ? 'bg-slate-700 text-white shadow-lg' : 'text-slate-500'}`}
              >
                <Phone className="w-4 h-4" /> Phone
              </button>
            </div>

            {/* Input fields */}
            {method === 'EMAIL' ? (
              <div className="space-y-4">
                <input 
                  type="email" 
                  placeholder="name@example.com" 
                  className="w-full px-5 py-4 bg-slate-800 border border-slate-700 rounded-2xl focus:outline-none focus:ring-2 focus:ring-emerald-500/50 text-sm"
                />
                <input 
                  type="password" 
                  placeholder="••••••••" 
                  className="w-full px-5 py-4 bg-slate-800 border border-slate-700 rounded-2xl focus:outline-none focus:ring-2 focus:ring-emerald-500/50 text-sm"
                />
              </div>
            ) : (
              <div className="flex gap-2">
                <div className="w-20 px-4 py-4 bg-slate-800 border border-slate-700 rounded-2xl text-center text-slate-500 text-sm font-bold">+91</div>
                <input 
                  type="tel" 
                  placeholder="98765 43210" 
                  className="flex-grow px-5 py-4 bg-slate-800 border border-slate-700 rounded-2xl focus:outline-none focus:ring-2 focus:ring-emerald-500/50 text-sm"
                />
              </div>
            )}

            <button 
              onClick={() => onAuth(UserRole.USER)}
              className="w-full py-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-2xl transition-all flex items-center justify-center gap-2 mt-6 uppercase tracking-widest text-sm shadow-xl shadow-emerald-500/20"
            >
              {isLogin ? 'Log In' : 'Create Account'} <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <p className="text-center mt-8 text-sm text-slate-500">
            {isLogin ? "Don't have an account?" : "Already have an account?"}
            <button 
              onClick={() => setIsLogin(!isLogin)}
              className="ml-2 text-emerald-400 font-bold hover:underline"
            >
              {isLogin ? 'Sign Up' : 'Log In'}
            </button>
          </p>

          {/* Quick Role Selection for Demo */}
          <div className="mt-10 pt-8 border-t border-slate-800 text-center">
            <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-4">Demo Role Selection</p>
            <div className="flex justify-center gap-4">
              <button onClick={() => onAuth(UserRole.USER)} className="text-[10px] font-bold text-slate-500 hover:text-emerald-400">User</button>
              <button onClick={() => onAuth(UserRole.OWNER)} className="text-[10px] font-bold text-slate-500 hover:text-emerald-400">Owner</button>
              <button onClick={() => onAuth(UserRole.ADMIN)} className="text-[10px] font-bold text-slate-500 hover:text-emerald-400">Admin</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthModal;
