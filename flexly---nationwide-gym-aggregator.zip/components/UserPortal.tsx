
import React, { useState, useEffect, useMemo } from 'react';
import { useLocation } from 'react-router-dom';
import { User, Gym, Booking, GymReview } from '../types';
// Fixed: Changed MOCK_BOOKINGS to MOCK_PAYMENTS to match constants.tsx exports
import { MOCK_GYMS, MOCK_PAYMENTS, MOCK_REVIEWS } from '../constants';
import { 
  Search, MapPin, Star, Filter, Heart, ChevronRight, X, QrCode, Sparkles, Ticket, 
  Map as MapIcon, Grid, CheckCircle2, CreditCard, ChevronLeft, Navigation, 
  Shield, Settings, Bell, Lock, Wallet, User as UserIcon, Calendar, Clock,
  ShoppingCart, Download, FileText, Info
} from 'lucide-react';
import { getGymSummary, getAIFitnessTip } from '../services/geminiService';

interface Props {
  user: User;
}

const UserPortal: React.FC<Props> = ({ user }) => {
  const [search, setSearch] = useState('');
  const [selectedGym, setSelectedGym] = useState<Gym | null>(null);
  const [aiTip, setAiTip] = useState('Loading daily fitness insight...');
  const [displayMode, setDisplayMode] = useState<'GRID' | 'MAP'>('GRID');
  const [showFilters, setShowFilters] = useState(false);
  
  // Advanced Filter States
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 1000]);
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>([]);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [minRating, setMinRating] = useState(0);

  const location = useLocation();

  useEffect(() => {
    getAIFitnessTip("stay consistent with working out").then(setAiTip);
  }, []);

  // Filter Logic
  const filteredGyms = useMemo(() => {
    return MOCK_GYMS.filter(g => {
      const matchesSearch = g.name.toLowerCase().includes(search.toLowerCase()) || 
                           g.location.toLowerCase().includes(search.toLowerCase());
      const matchesPrice = g.pricing.daily >= priceRange[0] && g.pricing.daily <= priceRange[1];
      const matchesRating = g.rating >= minRating;
      const matchesAmenities = selectedAmenities.length === 0 || 
                              selectedAmenities.every(a => g.amenities.includes(a));
      const matchesTags = selectedTags.length === 0 || 
                         selectedTags.some(t => g.tags.includes(t));
      
      return matchesSearch && matchesPrice && matchesRating && matchesAmenities && matchesTags;
    });
  }, [search, priceRange, minRating, selectedAmenities, selectedTags]);

  const allAmenities = useMemo(() => Array.from(new Set(MOCK_GYMS.flatMap(g => g.amenities))), []);
  const allTags = useMemo(() => Array.from(new Set(MOCK_GYMS.flatMap(g => g.tags))), []);

  const currentView = location.pathname === '/passes' ? 'PASSES' : location.pathname === '/profile' ? 'PROFILE' : 'DISCOVER';

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-8 pb-24">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-1">
          <h1 className="text-3xl font-black tracking-tight">
            {currentView === 'DISCOVER' ? `Hey ${user.name.split(' ')[0]}, let's crush it!` : 
             currentView === 'PASSES' ? 'Your Active Fitness Passes' : 'Account Settings'}
          </h1>
          <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-xl w-fit">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <p className="text-xs text-emerald-400 font-bold italic">{aiTip}</p>
          </div>
        </div>
      </div>

      {currentView === 'DISCOVER' && (
        <div className="space-y-6 animate-in fade-in duration-500">
          {/* Controls */}
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-grow">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 w-5 h-5" />
              <input 
                type="text"
                placeholder="Search gyms, cities (Mumbai, Bangalore...)"
                className="w-full pl-12 pr-4 py-4 bg-slate-900 border border-slate-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <button 
                onClick={() => setShowFilters(true)}
                className={`flex items-center gap-2 px-6 py-4 rounded-2xl font-bold transition-all border ${showFilters || selectedAmenities.length > 0 ? 'bg-emerald-500 text-slate-950 border-emerald-500' : 'bg-slate-900 border-slate-800 text-white hover:bg-slate-800'}`}
              >
                <Filter className="w-5 h-5" /> Filters
                {(selectedAmenities.length + selectedTags.length > 0) && <span className="ml-1 w-5 h-5 bg-slate-950 text-white rounded-full flex items-center justify-center text-[10px]">{selectedAmenities.length + selectedTags.length}</span>}
              </button>
              <div className="hidden md:flex bg-slate-900 rounded-2xl p-1 border border-slate-800">
                <button 
                  onClick={() => setDisplayMode('GRID')}
                  className={`p-3 rounded-xl transition-all ${displayMode === 'GRID' ? 'bg-slate-800 text-emerald-400 shadow-lg' : 'text-slate-500'}`}
                >
                  <Grid className="w-5 h-5" />
                </button>
                <button 
                  onClick={() => setDisplayMode('MAP')}
                  className={`p-3 rounded-xl transition-all ${displayMode === 'MAP' ? 'bg-slate-800 text-emerald-400 shadow-lg' : 'text-slate-500'}`}
                >
                  <MapIcon className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>

          {displayMode === 'GRID' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredGyms.map(gym => (
                <GymCard key={gym.id} gym={gym} onClick={() => setSelectedGym(gym)} />
              ))}
              {filteredGyms.length === 0 && (
                <div className="col-span-full py-20 text-center space-y-4">
                   <div className="w-20 h-20 bg-slate-900 rounded-full flex items-center justify-center mx-auto border border-slate-800">
                      <Search className="w-8 h-8 text-slate-700" />
                   </div>
                   <h3 className="text-xl font-bold">No gyms match your filters</h3>
                   <p className="text-slate-500">Try adjusting your filters or search terms.</p>
                   <button onClick={() => { setSearch(''); setSelectedAmenities([]); setSelectedTags([]); setPriceRange([0, 1000]); setMinRating(0); }} className="text-emerald-400 font-bold underline">Reset all filters</button>
                </div>
              )}
            </div>
          ) : (
            <div className="relative h-[650px] bg-slate-900 rounded-[3rem] border border-slate-800 overflow-hidden shadow-2xl">
              {/* Interactive Map Visual */}
              <div className="absolute inset-0 bg-slate-950 flex items-center justify-center opacity-40">
                <div className="w-full h-full bg-[url('https://api.mapbox.com/styles/v1/mapbox/dark-v11/static/77.5946,12.9716,11/1200x650?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTAwMHozNnByOHN3bm53ZnIifQ')] bg-cover"></div>
              </div>
              <div className="absolute inset-0 p-8 flex flex-col justify-end">
                <div className="flex flex-wrap gap-4">
                  {filteredGyms.map(gym => (
                    <div 
                      key={gym.id}
                      onClick={() => setSelectedGym(gym)}
                      className="group cursor-pointer bg-slate-900/90 backdrop-blur-xl border border-emerald-500/30 p-4 rounded-2xl flex items-center gap-4 hover:border-emerald-500 hover:scale-105 transition-all animate-in zoom-in-90"
                    >
                      <img src={gym.photos[0]} className="w-12 h-12 rounded-xl object-cover" />
                      <div>
                        <p className="font-black text-xs">{gym.name}</p>
                        <p className="text-[10px] text-emerald-400 font-bold">₹{gym.pricing.daily} Daily</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="absolute top-8 right-8 bg-slate-900/80 backdrop-blur-md p-4 rounded-2xl border border-slate-800 space-y-2">
                 <p className="text-[10px] font-black uppercase tracking-widest text-slate-500">Nearby Gyms</p>
                 <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full animate-ping"></div>
                    <span className="text-xs font-bold">{filteredGyms.length} Facilities Found</span>
                 </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Filter Modal */}
      {showFilters && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md" onClick={() => setShowFilters(false)}></div>
          <div className="bg-slate-900 border border-slate-800 w-full max-w-lg rounded-[2.5rem] overflow-hidden relative z-10 shadow-2xl animate-in zoom-in-95">
             <div className="p-8 border-b border-slate-800 flex justify-between items-center">
                <h3 className="text-xl font-black uppercase tracking-tight">Advanced Filters</h3>
                <button onClick={() => setShowFilters(false)} className="p-2 bg-slate-800 rounded-full text-slate-400 hover:text-white"><X className="w-5 h-5" /></button>
             </div>
             <div className="p-8 space-y-8 max-h-[70vh] overflow-y-auto custom-scrollbar">
                <div className="space-y-4">
                   <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Price Range (Daily Pass)</p>
                   <div className="flex items-center gap-4">
                      <span className="text-sm font-bold">₹{priceRange[0]}</span>
                      <input 
                        type="range" 
                        min="0" max="1000" 
                        value={priceRange[1]} 
                        onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                        className="flex-grow accent-emerald-500" 
                      />
                      <span className="text-sm font-bold">₹{priceRange[1]}</span>
                   </div>
                </div>

                <div className="space-y-4">
                   <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Minimum Rating</p>
                   <div className="flex gap-2">
                      {[3, 4, 4.5].map(r => (
                        <button 
                          key={r}
                          onClick={() => setMinRating(minRating === r ? 0 : r)}
                          className={`px-4 py-2 rounded-xl text-xs font-bold border transition-all ${minRating === r ? 'bg-emerald-500 border-emerald-500 text-slate-950' : 'bg-slate-800 border-slate-700 text-slate-400'}`}
                        >
                          {r}+ Stars
                        </button>
                      ))}
                   </div>
                </div>

                <div className="space-y-4">
                   <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Amenities</p>
                   <div className="flex flex-wrap gap-2">
                      {allAmenities.map(a => (
                        <button 
                          key={a}
                          onClick={() => setSelectedAmenities(prev => prev.includes(a) ? prev.filter(x => x !== a) : [...prev, a])}
                          className={`px-3 py-2 rounded-xl text-[10px] font-bold border transition-all uppercase tracking-wider ${selectedAmenities.includes(a) ? 'bg-emerald-500 border-emerald-500 text-slate-950' : 'bg-slate-800 border-slate-700 text-slate-400'}`}
                        >
                          {a}
                        </button>
                      ))}
                   </div>
                </div>
             </div>
             <div className="p-8 border-t border-slate-800 flex gap-4">
                <button onClick={() => { setSelectedAmenities([]); setSelectedTags([]); setPriceRange([0, 1000]); setMinRating(0); }} className="px-6 py-4 text-xs font-black uppercase text-slate-500 hover:text-white transition-all">Reset All</button>
                <button onClick={() => setShowFilters(false)} className="flex-grow py-4 bg-emerald-500 text-slate-950 font-black rounded-2xl text-xs uppercase tracking-widest">Apply Filters</button>
             </div>
          </div>
        </div>
      )}

      {selectedGym && (
        <GymModal gym={selectedGym} onClose={() => setSelectedGym(null)} />
      )}
    </div>
  );
};

const GymCard: React.FC<{ gym: Gym; onClick: () => void }> = ({ gym, onClick }) => {
  return (
    <div 
      onClick={onClick}
      className="group cursor-pointer bg-slate-900 border border-slate-800 rounded-[2.5rem] overflow-hidden hover:border-emerald-500/50 transition-all transform hover:-translate-y-2 shadow-2xl"
    >
      <div className="relative h-64">
        <img src={gym.photos[0]} alt={gym.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000" />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent opacity-60"></div>
        <div className="absolute top-6 right-6 flex gap-2">
          <div className="px-3 py-1 bg-emerald-500 rounded-lg text-[10px] font-black text-slate-950 uppercase tracking-tighter">
            {gym.tags[0]}
          </div>
        </div>
        <div className="absolute bottom-6 left-6 flex items-center gap-2">
          <div className="px-3 py-1.5 bg-slate-950/80 backdrop-blur-md rounded-xl flex items-center gap-1.5 text-xs font-bold text-white border border-white/5">
            <Star className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" /> {gym.rating}
          </div>
        </div>
      </div>
      <div className="p-8">
        <div className="flex justify-between items-start mb-3">
          <h3 className="text-2xl font-black truncate pr-4">{gym.name}</h3>
          <div className="text-right shrink-0">
            <p className="text-emerald-400 font-black text-xl leading-none">₹{gym.pricing.daily}</p>
            <p className="text-[9px] text-slate-500 uppercase font-black tracking-widest mt-1">Daily Access</p>
          </div>
        </div>
        <p className="text-slate-400 text-sm flex items-center gap-2 mb-6 font-medium">
          <MapPin className="w-4 h-4 text-emerald-500" /> {gym.location}
        </p>
        <div className="flex flex-wrap gap-2 mb-8 h-12 overflow-hidden">
          {gym.amenities.slice(0, 4).map(a => (
            <span key={a} className="px-3 py-1.5 bg-slate-800/80 text-slate-400 text-[9px] font-black rounded-lg border border-slate-700/50 uppercase tracking-tighter">{a}</span>
          ))}
        </div>
        <button className="w-full flex items-center justify-center gap-3 py-4 bg-slate-800 group-hover:bg-emerald-500 group-hover:text-slate-950 font-black text-xs rounded-2xl transition-all uppercase tracking-widest shadow-xl group-hover:shadow-emerald-500/20">
          Secure Pass <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

const GymModal: React.FC<{ gym: Gym; onClose: () => void }> = ({ gym, onClose }) => {
  const [summary, setSummary] = useState('Generating AI highlights...');
  const [selectedPlan, setSelectedPlan] = useState<'DAILY' | 'WEEKLY' | 'MONTHLY'>('DAILY');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [step, setStep] = useState<'DETAILS' | 'CHECKOUT' | 'SUCCESS'>('DETAILS');
  const [activePhoto, setActivePhoto] = useState(0);

  useEffect(() => {
    getGymSummary(gym.name, gym.amenities, gym.location).then(setSummary);
  }, [gym]);

  const pricingMap = {
    DAILY: gym.pricing.daily,
    WEEKLY: gym.pricing.weekly,
    MONTHLY: gym.pricing.monthly
  };

  const calculateExpiry = () => {
    const start = new Date(selectedDate);
    if (selectedPlan === 'DAILY') start.setDate(start.getDate() + 1);
    else if (selectedPlan === 'WEEKLY') start.setDate(start.getDate() + 7);
    else if (selectedPlan === 'MONTHLY') start.setDate(start.getDate() + 30);
    return start.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
  };

  const handlePayment = () => {
    setStep('CHECKOUT');
    setTimeout(() => {
      setStep('SUCCESS');
    }, 2500);
  };

  if (step === 'SUCCESS') {
    const passId = `FLX-${Math.random().toString(36).substring(7).toUpperCase()}`;
    return (
      <div className="fixed inset-0 z-[120] flex items-center justify-center p-4">
        <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-xl"></div>
        <div className="bg-slate-900 border border-emerald-500/30 w-full max-w-lg rounded-[3rem] relative z-10 p-10 text-center space-y-8 shadow-2xl animate-in zoom-in-95">
          <div className="w-24 h-24 bg-emerald-500 rounded-full mx-auto flex items-center justify-center text-slate-950 shadow-2xl shadow-emerald-500/40">
            <CheckCircle2 className="w-12 h-12" />
          </div>
          <div className="space-y-2">
            <h2 className="text-4xl font-black tracking-tight">Access Unlocked!</h2>
            <p className="text-slate-400 font-medium italic">Invoice #{Math.floor(Math.random() * 999999)} generated successfully.</p>
          </div>
          
          {/* Virtual Pass Design */}
          <div className="bg-white rounded-[2rem] overflow-hidden text-slate-950 shadow-2xl">
            <div className="bg-emerald-500 p-6 flex justify-between items-center">
               <div className="text-left">
                  <p className="text-[10px] font-black uppercase tracking-widest opacity-60">Flexly Official Pass</p>
                  <h4 className="text-xl font-black">{gym.name}</h4>
               </div>
               <div className="w-10 h-10 bg-slate-950 rounded-lg flex items-center justify-center text-emerald-400 font-black">F</div>
            </div>
            <div className="p-8 space-y-6">
               <div className="grid grid-cols-2 gap-4 text-left">
                  <div>
                    <p className="text-[8px] font-black uppercase text-slate-400 tracking-widest">Type</p>
                    <p className="text-xs font-black uppercase tracking-tight">{selectedPlan} ACCESS</p>
                  </div>
                  <div>
                    <p className="text-[8px] font-black uppercase text-slate-400 tracking-widest">Start Date</p>
                    <p className="text-xs font-black uppercase tracking-tight">{selectedDate}</p>
                  </div>
                  <div>
                    <p className="text-[8px] font-black uppercase text-slate-400 tracking-widest">Gym ID</p>
                    <p className="text-xs font-black uppercase tracking-tight">LOC-{gym.id}</p>
                  </div>
                  <div>
                    <p className="text-[8px] font-black uppercase text-slate-400 tracking-widest">Pass ID</p>
                    <p className="text-xs font-black uppercase tracking-tight">{passId}</p>
                  </div>
               </div>
               <div className="py-6 border-t border-dashed border-slate-200 flex flex-col items-center gap-4">
                  <QrCode className="w-32 h-32" />
                  <p className="text-[10px] font-bold text-slate-400 tracking-[0.3em]">SCAN AT RECEPTION</p>
               </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
             <button onClick={onClose} className="py-4 bg-slate-800 text-white font-black rounded-2xl text-xs uppercase tracking-widest hover:bg-slate-700 transition-all flex items-center justify-center gap-2">
                <Download className="w-4 h-4" /> Save as PDF
             </button>
             <button onClick={onClose} className="py-4 bg-emerald-500 text-slate-950 font-black rounded-2xl text-xs uppercase tracking-widest hover:bg-emerald-400 transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20">
                <Grid className="w-4 h-4" /> To Dashboard
             </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md" onClick={onClose}></div>
      <div className="bg-slate-900 border border-slate-800 w-full max-w-6xl max-h-[90vh] rounded-[3rem] overflow-hidden relative z-10 flex flex-col lg:flex-row shadow-2xl animate-in slide-in-from-bottom-8 duration-500">
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 p-3 bg-slate-800/80 backdrop-blur-md rounded-full text-slate-400 hover:text-white z-20 border border-white/5 shadow-xl transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        {step === 'DETAILS' ? (
          <>
            {/* Gallery Section */}
            <div className="w-full lg:w-1/2 h-80 lg:h-auto overflow-hidden relative group">
              <img src={gym.photos[activePhoto]} className="w-full h-full object-cover animate-in fade-in duration-700" alt={gym.name} />
              <div className="absolute inset-x-0 bottom-8 px-8 flex gap-3 overflow-x-auto no-scrollbar">
                 {gym.photos.map((p, i) => (
                   <button 
                    key={i} 
                    onClick={() => setActivePhoto(i)}
                    className={`min-w-[80px] h-20 rounded-2xl border-2 overflow-hidden transition-all transform hover:scale-105 ${activePhoto === i ? 'border-emerald-500 scale-110 shadow-xl' : 'border-white/20 opacity-60'}`}
                   >
                      <img src={p} className="w-full h-full object-cover" />
                   </button>
                 ))}
              </div>
              <div className="absolute top-8 left-8">
                 <div className="flex items-center gap-2 px-4 py-2 bg-slate-950/70 backdrop-blur-md rounded-full border border-white/10 text-xs font-black uppercase tracking-widest">
                    <MapPin className="w-3.5 h-3.5 text-emerald-400" /> {gym.location.split(',')[0]}
                 </div>
              </div>
            </div>

            {/* Information Section */}
            <div className="w-full lg:w-1/2 p-8 lg:p-12 overflow-y-auto custom-scrollbar bg-slate-900">
              <div className="space-y-8">
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <span className="px-4 py-1.5 bg-emerald-500/10 text-emerald-400 text-[10px] font-black rounded-full uppercase tracking-widest border border-emerald-500/20">Certified Flexly Partner</span>
                  </div>
                  <h2 className="text-5xl font-black mb-4 tracking-tighter">{gym.name}</h2>
                  <div className="flex flex-wrap items-center gap-6">
                     <div className="flex items-center gap-2 text-yellow-400 font-black">
                        <Star className="w-5 h-5 fill-current" /> {gym.rating} <span className="text-slate-500 font-bold">({gym.reviewsCount} reviews)</span>
                     </div>
                     <div className="flex items-center gap-2 text-slate-400 font-bold text-sm">
                        <Info className="w-4 h-4" /> Open Now
                     </div>
                  </div>
                </div>

                {/* Timings & Description */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                   <div className="p-6 bg-slate-800/40 rounded-3xl border border-slate-700/50 space-y-4">
                      <h4 className="text-xs font-black text-slate-500 uppercase tracking-widest flex items-center gap-2"><Clock className="w-4 h-4" /> Gym Timings</h4>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                           <span className="font-medium text-slate-400">Weekdays:</span>
                           <span className="font-bold text-white">{gym.timings.weekdays}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                           <span className="font-medium text-slate-400">Weekends:</span>
                           <span className="font-bold text-white">{gym.timings.weekends}</span>
                        </div>
                      </div>
                   </div>
                   <div className="p-6 bg-emerald-500/10 rounded-3xl border border-emerald-500/20">
                      <h4 className="text-xs font-black text-emerald-400 uppercase tracking-widest flex items-center gap-2 mb-2"><Sparkles className="w-4 h-4" /> AI Highlight</h4>
                      <p className="text-sm text-slate-300 italic leading-relaxed">"{summary}"</p>
                   </div>
                </div>

                {/* Amenities Grid */}
                <div>
                   <h4 className="text-xs font-black text-slate-500 uppercase tracking-widest mb-4">Key Features</h4>
                   <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                      {gym.amenities.map(a => (
                        <div key={a} className="flex items-center gap-3 p-3 bg-slate-800/30 rounded-2xl border border-slate-700/30">
                           <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                           <span className="text-xs font-bold text-slate-300 truncate">{a}</span>
                        </div>
                      ))}
                   </div>
                </div>

                {/* Plan Selection */}
                <div className="space-y-6">
                  <h4 className="text-xs font-black text-slate-500 uppercase tracking-widest">Choose Access Tier</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {(['DAILY', 'WEEKLY', 'MONTHLY'] as const).map(tier => (
                      <button 
                        key={tier}
                        onClick={() => setSelectedPlan(tier)}
                        className={`p-6 rounded-[2rem] border-2 transition-all flex flex-col items-center gap-2 group ${selectedPlan === tier ? 'bg-emerald-500 border-emerald-500 text-slate-950' : 'bg-slate-800 border-slate-700 text-slate-400 hover:border-slate-500'}`}
                      >
                        <p className={`text-[10px] font-black uppercase tracking-widest ${selectedPlan === tier ? 'opacity-60' : 'text-slate-500'}`}>{tier}</p>
                        <p className="text-2xl font-black">₹{gym.pricing[tier.toLowerCase() as keyof typeof gym.pricing]}</p>
                      </button>
                    ))}
                  </div>

                  {/* Date Picker */}
                  <div className="space-y-4">
                    <h4 className="text-xs font-black text-slate-500 uppercase tracking-widest">Select Start Date</h4>
                    <div className="relative">
                       <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-emerald-400 w-5 h-5" />
                       <input 
                        type="date" 
                        min={new Date().toISOString().split('T')[0]}
                        value={selectedDate}
                        onChange={(e) => setSelectedDate(e.target.value)}
                        className="w-full pl-12 pr-6 py-4 bg-slate-800 border border-slate-700 rounded-2xl font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500/50 appearance-none"
                       />
                    </div>
                  </div>
                </div>

                {/* Checkout Summary */}
                <div className="pt-8 border-t border-slate-800">
                  <div className="flex justify-between items-center mb-6">
                    <div>
                       <p className="text-2xl font-black">Total: ₹{pricingMap[selectedPlan]}</p>
                       <p className="text-xs text-slate-500 font-bold italic">Pass valid until: {calculateExpiry()}</p>
                    </div>
                    <div className="flex flex-col items-end opacity-40 grayscale group-hover:grayscale-0 transition-all">
                       <div className="flex gap-4">
                          <img src="https://upload.wikimedia.org/wikipedia/commons/b/ba/Stripe_Logo%2C_revised_2016.svg" className="h-6" />
                          <img src="https://upload.wikimedia.org/wikipedia/commons/b/b5/Razorpay_logo.svg" className="h-4" />
                       </div>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                     <button className="py-5 bg-slate-800 text-white font-black rounded-2xl text-xs uppercase tracking-widest flex items-center justify-center gap-3 hover:bg-slate-700 transition-all">
                        <ShoppingCart className="w-5 h-5" /> Add to Cart
                     </button>
                     <button 
                        onClick={handlePayment}
                        className="py-5 bg-emerald-500 text-slate-950 font-black rounded-2xl text-sm uppercase tracking-widest shadow-2xl shadow-emerald-500/30 hover:bg-emerald-400 transition-all flex items-center justify-center gap-3 transform active:scale-95"
                      >
                        Secure Pay Now <ChevronRight className="w-5 h-5" />
                     </button>
                  </div>
                  <div className="mt-6 flex flex-wrap justify-center gap-x-8 gap-y-2 opacity-40">
                    <span className="text-[9px] font-black uppercase tracking-widest flex items-center gap-2"><Shield className="w-4 h-4" /> Secure SSL Checkout</span>
                    <span className="text-[9px] font-black uppercase tracking-widest flex items-center gap-2"><Settings className="w-4 h-4" /> Terms & Conditions</span>
                    <span className="text-[9px] font-black uppercase tracking-widest flex items-center gap-2"><CheckCircle2 className="w-4 h-4" /> Verified Gym</span>
                  </div>
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="w-full h-full p-20 flex flex-col items-center justify-center space-y-12">
            <div className="relative">
              <div className="w-24 h-24 border-8 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                 <Shield className="w-8 h-8 text-emerald-500 animate-pulse" />
              </div>
            </div>
            <div className="text-center space-y-4">
              <h2 className="text-3xl font-black tracking-tight">Validating Secure Transaction</h2>
              <p className="text-slate-400 max-w-sm font-medium">Please do not refresh. We are communicating with your bank and preparing your digital fitness pass...</p>
            </div>
            <div className="p-8 bg-slate-800/30 rounded-3xl border border-slate-700/50 flex flex-col items-center gap-6 w-full max-w-md">
               <p className="text-[10px] font-black uppercase tracking-widest text-slate-500">Invoice Breakdown</p>
               <div className="w-full space-y-3">
                  <div className="flex justify-between text-sm">
                     <span className="text-slate-400">Flexly {selectedPlan} Access</span>
                     <span className="font-bold">₹{pricingMap[selectedPlan]}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                     <span className="text-slate-400">Platform Convenience Fee</span>
                     <span className="font-bold text-emerald-400">₹0 (Promo)</span>
                  </div>
                  <div className="pt-3 border-t border-slate-700 flex justify-between font-black">
                     <span>Final Amount</span>
                     <span>₹{pricingMap[selectedPlan]}</span>
                  </div>
               </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const ProfileNavItem: React.FC<{ icon: React.ReactNode; label: string; active?: boolean }> = ({ icon, label, active }) => (
  <button className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold transition-all ${active ? 'bg-emerald-500/10 text-emerald-400' : 'text-slate-500 hover:bg-slate-800 hover:text-slate-300'}`}>
    {icon} {label}
  </button>
);

export default UserPortal;
