
import React, { useState, useMemo } from 'react';
import { useLocation } from 'react-router-dom';
import { User, Gym, Payout } from '../types';
import { MOCK_GYMS, MOCK_PAYOUTS, PLATFORM_CONFIG } from '../constants';
import { 
  Users, Wallet, ArrowUpRight, ArrowDownRight, Plus, BarChart3, Clock, 
  CheckCircle2, AlertCircle, FileText, Upload, Settings, MoreVertical, 
  Dumbbell, ShieldCheck, ChevronRight, MapPin, CreditCard, X, Video, 
  Calendar, Info, Download, Filter, Search, Trash
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const data = [
  { name: 'Mon', revenue: 4000 },
  { name: 'Tue', revenue: 3000 },
  { name: 'Wed', revenue: 5000 },
  { name: 'Thu', revenue: 2780 },
  { name: 'Fri', revenue: 1890 },
  { name: 'Sat', revenue: 6390 },
  { name: 'Sun', revenue: 8490 },
];

const OwnerPortal: React.FC<{ user: User }> = ({ user }) => {
  const location = useLocation();
  const [gyms, setGyms] = useState<Gym[]>(MOCK_GYMS.filter(g => g.ownerId === 'owner1' || g.ownerId === user.id));
  const [payouts, setPayouts] = useState<Payout[]>(MOCK_PAYOUTS);
  const [showGymModal, setShowGymModal] = useState<{ show: boolean, gym?: Gym }>({ show: false });
  const [isProcessingWithdrawal, setIsProcessingWithdrawal] = useState(false);
  
  const [payoutSearch, setPayoutSearch] = useState('');
  const [dateRange, setDateRange] = useState({ start: '', end: '' });

  const activeTab = location.pathname === '/gyms' ? 'GYMS' : location.pathname === '/payouts' ? 'PAYOUTS' : 'DASHBOARD';

  const outstandingBalance = useMemo(() => {
    return payouts.filter(p => p.status === 'PENDING').reduce((sum, p) => sum + p.netAmount, 0);
  }, [payouts]);

  const canWithdraw = outstandingBalance >= PLATFORM_CONFIG.minWithdrawalThreshold;

  const handleWithdraw = () => {
    setIsProcessingWithdrawal(true);
    setTimeout(() => {
      setIsProcessingWithdrawal(false);
      alert(`Withdrawal initiated! Reference: WDR-${Math.random().toString(36).substr(2, 6).toUpperCase()}. It will be processed in 1 Business Day.`);
    }, 1500);
  };

  const filteredPayouts = useMemo(() => {
    return payouts.filter(p => {
      const matchesSearch = p.userName.toLowerCase().includes(payoutSearch.toLowerCase()) || p.id.toLowerCase().includes(payoutSearch.toLowerCase());
      const matchesDate = (!dateRange.start || p.date >= dateRange.start) && (!dateRange.end || p.date <= dateRange.end);
      return matchesSearch && matchesDate;
    });
  }, [payouts, payoutSearch, dateRange]);

  const handleSaveGym = (gymData: Partial<Gym>) => {
    if (showGymModal.gym) {
      setGyms(prev => prev.map(g => g.id === showGymModal.gym!.id ? { ...g, ...gymData } as Gym : g));
      alert("Changes saved. Your facility remains live but some details may be subject to review.");
    } else {
      const newGym: Gym = {
        id: Math.random().toString(36).substr(2, 9),
        ownerId: user.id,
        ownerName: user.name,
        name: gymData.name || 'New Gym',
        location: gymData.location || 'Unknown',
        city: gymData.city || 'Unknown',
        state: gymData.state || 'Unknown',
        coordinates: { lat: 0, lng: 0 },
        description: gymData.description || '',
        amenities: gymData.amenities || [],
        photos: gymData.photos || [],
        pricing: gymData.pricing || { daily: 0, weekly: 0, monthly: 0 },
        timings: gymData.timings || { weekdays: '9-9', weekends: '10-6' },
        rating: 0,
        status: 'PENDING',
        reviewsCount: 0,
        tags: []
      };
      setGyms(prev => [...prev, newGym]);
      alert("New facility submitted! It will appear on the platform once the Admin approves your listing (typically < 24h).");
    }
    setShowGymModal({ show: false });
  };

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-8 pb-24 text-slate-100">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h1 className="text-4xl font-black tracking-tight uppercase flex items-center gap-4">
            {activeTab === 'DASHBOARD' ? 'Partner Command' : 
             activeTab === 'GYMS' ? 'Inventory' : 'Financial Ledger'}
          </h1>
          <p className="text-slate-500 font-bold mt-1 tracking-tight">Managing {gyms.length} Facilities • {user.name}</p>
        </div>
        <div className="flex gap-4 w-full md:w-auto">
          <div className={`flex items-center gap-3 px-6 py-4 border-2 rounded-2xl font-black text-xs uppercase tracking-widest transition-all ${user.kycStatus === 'VERIFIED' ? 'border-emerald-500/30 text-emerald-400 bg-emerald-500/5' : 'border-amber-500/30 text-amber-500 bg-amber-500/5'}`}>
            <ShieldCheck className="w-5 h-5" /> 
            {user.kycStatus === 'VERIFIED' ? 'Verified Partner' : 'KYC Validation Pending'}
          </div>
          <button 
            onClick={() => setShowGymModal({ show: true })}
            className="flex-grow md:flex-none flex items-center justify-center gap-3 px-8 py-4 bg-emerald-500 text-slate-950 font-black rounded-2xl hover:bg-emerald-400 transition-all shadow-xl shadow-emerald-500/20 uppercase tracking-widest text-xs"
          >
            <Plus className="w-5 h-5" /> Expand Network
          </button>
        </div>
      </div>

      {activeTab === 'DASHBOARD' && (
        <div className="space-y-8 animate-in fade-in duration-500">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatCard title="Total Volume" value={`₹${payouts.reduce((a, b) => a + b.grossAmount, 0).toLocaleString()}`} icon={<Wallet className="w-6 h-6 text-emerald-400" />} change="+12%" />
            <StatCard title="Settlement Cycle" value="15 Days" icon={<Clock className="w-6 h-6 text-amber-400" />} />
            <StatCard title="Network Rating" value="4.8" icon={<StarIcon className="w-6 h-6 text-yellow-400" />} />
            <StatCard title="Active Subs" value="12" icon={<Users className="w-6 h-6 text-emerald-400" />} change="+3 today" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 bg-slate-900/50 border border-slate-800 p-8 rounded-[2.5rem] shadow-2xl">
              <h3 className="text-xl font-black mb-10 uppercase tracking-tight">Revenue Trajectory</h3>
              <div className="h-80 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={data}>
                    <defs>
                      <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                    <XAxis dataKey="name" stroke="#64748b" axisLine={false} tickLine={false} dy={10} />
                    <YAxis stroke="#64748b" axisLine={false} tickLine={false} dx={-10} />
                    <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '16px' }} />
                    <Area type="monotone" dataKey="revenue" stroke="#10b981" fillOpacity={1} fill="url(#colorRev)" strokeWidth={4} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-slate-900/50 border border-slate-800 p-8 rounded-[2.5rem] shadow-2xl space-y-8">
              <h3 className="text-xl font-black uppercase tracking-tight">Quick Actions</h3>
              <div className="space-y-4">
                 <QuickLink icon={<Download className="w-5 h-5" />} label="Tax Certificates 2024" />
                 <QuickLink icon={<FileText className="w-5 h-5" />} label="Service Level Agreement" />
                 <QuickLink icon={<Settings className="w-5 h-5" />} label="Operational Settings" />
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'GYMS' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 animate-in slide-in-from-bottom-4 duration-500">
          {gyms.map(gym => (
            <div key={gym.id} className="bg-slate-900 border border-slate-800 rounded-[2.5rem] overflow-hidden group shadow-2xl hover:border-emerald-500/30 transition-all flex flex-col">
              <div className="h-56 overflow-hidden relative">
                <img src={gym.photos[0]} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" />
                <div className="absolute top-6 left-6">
                  <span className={`px-3 py-1 text-[10px] font-black rounded-lg uppercase tracking-widest ${gym.status === 'APPROVED' ? 'bg-emerald-500 text-slate-950' : 'bg-amber-500 text-slate-950'}`}>
                    {gym.status}
                  </span>
                </div>
              </div>
              <div className="p-8 flex-grow flex flex-col">
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <h3 className="text-2xl font-black tracking-tight">{gym.name}</h3>
                    <p className="text-xs text-slate-500 font-bold mt-1 flex items-center gap-2"><MapPin className="w-3 h-3" /> {gym.city}, {gym.state}</p>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-3 mb-8">
                  <PriceTile label="Daily" value={gym.pricing.daily} />
                  <PriceTile label="Weekly" value={gym.pricing.weekly} />
                  <PriceTile label="Monthly" value={gym.pricing.monthly} />
                </div>
                <button 
                  onClick={() => setShowGymModal({ show: true, gym })}
                  className="w-full py-4 bg-slate-800 hover:bg-slate-700 text-xs font-black uppercase tracking-widest rounded-2xl transition-all border border-slate-700 mt-auto"
                >
                  Configure Facility
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'PAYOUTS' && (
        <div className="space-y-8 animate-in fade-in duration-500">
           <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-slate-900 border border-slate-800 p-10 rounded-[2.5rem] shadow-2xl space-y-6 relative overflow-hidden group">
                 <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:scale-125 transition-transform"><Wallet className="w-20 h-20" /></div>
                 <div>
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-2">Withdrawable Balance</p>
                    <h3 className="text-5xl font-black text-emerald-400 tracking-tighter">₹{outstandingBalance.toLocaleString()}</h3>
                 </div>
                 <div className="space-y-4">
                    <button 
                      disabled={!canWithdraw || isProcessingWithdrawal}
                      onClick={handleWithdraw}
                      className={`w-full py-5 font-black rounded-2xl transition-all uppercase text-xs tracking-widest shadow-2xl flex items-center justify-center gap-3 ${canWithdraw ? 'bg-white text-slate-950 hover:bg-emerald-400 shadow-white/5' : 'bg-slate-800 text-slate-500 cursor-not-allowed opacity-50'}`}
                    >
                       {isProcessingWithdrawal ? <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></div> : <ArrowUpRight className="w-5 h-5" />}
                       {canWithdraw ? 'Process Withdrawal' : `Min ₹${PLATFORM_CONFIG.minWithdrawalThreshold} Required`}
                    </button>
                 </div>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-10 rounded-[2.5rem] shadow-2xl">
                 <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-2">Platform Fees (Automatic Deduct)</p>
                 <h3 className="text-5xl font-black text-rose-500 tracking-tighter">{(PLATFORM_CONFIG.commissionRate * 100).toFixed(0)}%</h3>
                 <p className="text-[10px] text-slate-600 font-bold uppercase mt-4 tracking-widest italic">Fees are auto-deducted from total gross volume at settlement.</p>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-10 rounded-[2.5rem] shadow-2xl flex flex-col justify-between">
                 <div>
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-2">Extract Subs Data</p>
                    <h3 className="text-2xl font-black tracking-tighter">Lifetime CSV</h3>
                 </div>
                 <button onClick={() => alert("Downloading member subscription report (CSV)...")} className="w-full py-4 bg-slate-800 text-slate-300 font-black rounded-xl transition-all uppercase text-[10px] tracking-widest flex items-center justify-center gap-3 border border-slate-700 mt-6">
                    <Download className="w-4 h-4" /> Export Subs Data (CSV)
                 </button>
              </div>
           </div>
        </div>
      )}

      {showGymModal.show && (
        <GymFormModal 
          gym={showGymModal.gym} 
          onClose={() => setShowGymModal({ show: false })} 
          onSave={handleSaveGym}
        />
      )}
    </div>
  );
};

const StatCard: React.FC<{ title: string; value: string; icon: React.ReactNode; change?: string }> = ({ title, value, icon, change }) => (
  <div className="bg-slate-900/50 border border-slate-800 p-8 rounded-[2rem] hover:border-emerald-500/30 transition-all group shadow-xl">
    <div className="flex justify-between items-start mb-6">
      <div className="p-4 bg-slate-800 rounded-2xl group-hover:bg-emerald-500/10 transition-colors group-hover:scale-110 duration-500">{icon}</div>
      {change && <div className="text-emerald-400 text-[10px] font-black uppercase tracking-widest">{change}</div>}
    </div>
    <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.2em]">{title}</p>
    <h3 className="text-3xl font-black mt-2 tracking-tighter">{value}</h3>
  </div>
);

const PriceTile: React.FC<{ label: string; value: number }> = ({ label, value }) => (
  <div className="text-center p-4 bg-slate-800/40 border border-slate-700/50 rounded-2xl">
    <p className="text-[8px] text-slate-500 uppercase font-black tracking-widest mb-1">{label}</p>
    <p className="font-black text-emerald-400 text-sm">₹{value}</p>
  </div>
);

const QuickLink: React.FC<{ icon: React.ReactNode; label: string }> = ({ icon, label }) => (
  <button className="w-full flex items-center justify-between p-4 bg-slate-800/50 hover:bg-slate-800 border border-slate-700/50 rounded-2xl transition-all group">
     <div className="flex items-center gap-3">
        <div className="text-emerald-500 group-hover:scale-110 transition-transform">{icon}</div>
        <span className="text-xs font-bold text-slate-300 group-hover:text-white transition-colors">{label}</span>
     </div>
     <ChevronRight className="w-4 h-4 text-slate-600" />
  </button>
);

const StarIcon = ({ className }: { className?: string }) => (
  <svg className={className} fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" /></svg>
);

const GymFormModal: React.FC<{ gym?: Gym; onClose: () => void, onSave: (data: Partial<Gym>) => void }> = ({ gym, onClose, onSave }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<Partial<Gym>>(gym || {
    name: '',
    location: '',
    city: '',
    state: '',
    description: '',
    amenities: [],
    photos: [],
    videoUrl: '',
    pricing: { daily: 0, weekly: 0, monthly: 0 },
    timings: { weekdays: '06:00 AM - 10:00 PM', weekends: '08:00 AM - 06:00 PM' },
    tags: []
  });

  const amenitiesOptions = ['Showers', 'Sauna', 'WiFi', 'Cafe', 'Personal Training', 'Free Weights', 'Cardio', 'Zumba', 'Steam Room'];

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md" onClick={onClose}></div>
      <div className="bg-slate-900 border border-slate-800 w-full max-w-2xl rounded-[3rem] overflow-hidden relative z-10 shadow-2xl animate-in zoom-in-95">
        <div className="p-10 border-b border-slate-800 flex justify-between items-center bg-slate-900/50 backdrop-blur-xl sticky top-0 z-10">
          <div>
             <h3 className="text-3xl font-black uppercase tracking-tight">{gym ? 'Configure Facility' : 'Register New Location'}</h3>
             <p className="text-xs text-slate-500 font-bold mt-1">Step {step} of 3 • Listing Approval Required</p>
          </div>
          <button onClick={onClose} className="p-3 bg-slate-800 rounded-full text-slate-400 hover:text-white transition-all"><X className="w-6 h-6" /></button>
        </div>

        <div className="p-10 max-h-[70vh] overflow-y-auto custom-scrollbar space-y-8">
          {step === 1 && (
            <div className="space-y-6 animate-in fade-in duration-300">
               <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Gym Entity Name</label>
                  <input type="text" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} className="w-full px-6 py-4 bg-slate-800 border border-slate-700 rounded-2xl text-sm font-bold" placeholder="e.g. Iron Temple Elite" />
               </div>
               <div className="grid grid-cols-2 gap-4">
                 <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">City</label>
                    <input type="text" value={formData.city} onChange={(e) => setFormData({ ...formData, city: e.target.value })} className="w-full px-6 py-4 bg-slate-800 border border-slate-700 rounded-2xl text-sm font-bold" placeholder="Mumbai" />
                 </div>
                 <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">State</label>
                    <input type="text" value={formData.state} onChange={(e) => setFormData({ ...formData, state: e.target.value })} className="w-full px-6 py-4 bg-slate-800 border border-slate-700 rounded-2xl text-sm font-bold" placeholder="Maharashtra" />
                 </div>
               </div>
               <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Full Address</label>
                  <input type="text" value={formData.location} onChange={(e) => setFormData({ ...formData, location: e.target.value })} className="w-full px-6 py-4 bg-slate-800 border border-slate-700 rounded-2xl text-sm font-bold" placeholder="e.g. Indiranagar, Bangalore" />
               </div>
               <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Marketing Description</label>
                  <textarea rows={4} value={formData.description} onChange={(e) => setFormData({ ...formData, description: e.target.value })} className="w-full px-6 py-4 bg-slate-800 border border-slate-700 rounded-2xl text-sm font-bold resize-none" placeholder="Describe your gym..." />
               </div>
               <div className="space-y-4">
                  <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Amenities</label>
                  <div className="flex flex-wrap gap-2">
                    {amenitiesOptions.map(a => (
                      <button key={a} onClick={() => { const current = formData.amenities || []; setFormData({ ...formData, amenities: current.includes(a) ? current.filter(x => x !== a) : [...current, a] }); }} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all ${formData.amenities?.includes(a) ? 'bg-emerald-500 border-emerald-500 text-slate-950' : 'bg-slate-800 border-slate-700 text-slate-500 hover:text-white'}`}>{a}</button>
                    ))}
                  </div>
               </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-10 animate-in fade-in duration-300">
               <div className="space-y-6">
                  <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Access Pricing (INR)</label>
                  <div className="grid grid-cols-3 gap-6">
                    <div className="space-y-2">
                       <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest text-center">Daily</p>
                       <input type="number" value={formData.pricing?.daily} onChange={(e) => setFormData({ ...formData, pricing: { ...formData.pricing!, daily: parseInt(e.target.value) } })} className="w-full px-4 py-4 bg-slate-800 border border-slate-700 rounded-2xl text-center font-black text-emerald-400 focus:outline-none" />
                    </div>
                    <div className="space-y-2">
                       <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest text-center">Weekly</p>
                       <input type="number" value={formData.pricing?.weekly} onChange={(e) => setFormData({ ...formData, pricing: { ...formData.pricing!, weekly: parseInt(e.target.value) } })} className="w-full px-4 py-4 bg-slate-800 border border-slate-700 rounded-2xl text-center font-black text-emerald-400 focus:outline-none" />
                    </div>
                    <div className="space-y-2">
                       <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest text-center">Monthly</p>
                       <input type="number" value={formData.pricing?.monthly} onChange={(e) => setFormData({ ...formData, pricing: { ...formData.pricing!, monthly: parseInt(e.target.value) } })} className="w-full px-4 py-4 bg-slate-800 border border-slate-700 rounded-2xl text-center font-black text-emerald-400 focus:outline-none" />
                    </div>
                  </div>
               </div>
               <div className="space-y-6">
                  <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Schedules</label>
                  <div className="grid grid-cols-2 gap-6">
                    <input type="text" value={formData.timings?.weekdays} onChange={(e) => setFormData({ ...formData, timings: { ...formData.timings!, weekdays: e.target.value } })} className="w-full px-4 py-4 bg-slate-800 border border-slate-700 rounded-2xl font-bold text-sm" placeholder="Mon-Fri" />
                    <input type="text" value={formData.timings?.weekends} onChange={(e) => setFormData({ ...formData, timings: { ...formData.timings!, weekends: e.target.value } })} className="w-full px-4 py-4 bg-slate-800 border border-slate-700 rounded-2xl font-bold text-sm" placeholder="Sat-Sun" />
                  </div>
               </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-8 animate-in fade-in duration-300">
               <div className="space-y-4">
                  <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Media URLs</label>
                  <div className="grid grid-cols-2 gap-4">
                    {(formData.photos || []).map((url, i) => (
                      <div key={i} className="relative aspect-video rounded-2xl overflow-hidden border border-slate-700">
                        <img src={url} className="w-full h-full object-cover" />
                        <button onClick={() => setFormData({ ...formData, photos: formData.photos?.filter((_, idx) => idx !== i) })} className="absolute top-2 right-2 p-1.5 bg-rose-500 rounded-lg text-white"><Trash className="w-3.5 h-3.5" /></button>
                      </div>
                    ))}
                    <button onClick={() => { const url = prompt('Enter Image URL:'); if (url) setFormData({ ...formData, photos: [...(formData.photos || []), url] }); }} className="aspect-video bg-slate-800 border-2 border-dashed border-slate-700 rounded-2xl flex flex-col items-center justify-center text-slate-600 hover:text-emerald-500 hover:border-emerald-500 transition-all"><Plus className="w-8 h-8 mb-2" /><span className="text-[10px] font-black uppercase tracking-widest">Add Image</span></button>
                  </div>
               </div>
               <input type="text" value={formData.videoUrl} onChange={(e) => setFormData({ ...formData, videoUrl: e.target.value })} className="w-full px-6 py-4 bg-slate-800 border border-slate-700 rounded-2xl text-sm font-bold" placeholder="Video Link (optional)" />
            </div>
          )}
        </div>

        <div className="p-10 border-t border-slate-800 flex justify-between gap-4 bg-slate-900/50">
          <button disabled={step === 1} onClick={() => setStep(step - 1)} className={`px-8 py-4 text-xs font-black uppercase tracking-widest rounded-2xl transition-all ${step === 1 ? 'text-slate-700' : 'text-slate-400 hover:text-white bg-slate-800'}`}>Back</button>
          {step < 3 ? (
            <button onClick={() => setStep(step + 1)} className="flex-grow py-4 bg-white text-slate-950 font-black rounded-2xl text-xs uppercase tracking-widest hover:bg-emerald-400 transition-all">Continue</button>
          ) : (
            <button onClick={() => onSave(formData)} className="flex-grow py-4 bg-emerald-500 text-slate-950 font-black rounded-2xl text-xs uppercase tracking-widest hover:bg-emerald-400 shadow-2xl shadow-emerald-500/20 transition-all">Finalize & Submit</button>
          )}
        </div>
      </div>
    </div>
  );
};

export default OwnerPortal;
